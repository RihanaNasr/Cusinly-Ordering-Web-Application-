# food_ordering_webapp
Food ordering platform that enables users to browse menus, customize orders, make secure payments, and track deliveries. The system will also provide restaurant owners with a user-friendly dashboard for menu management and order processing furthermore it provides food recipes to enhance the overall dining experience
Drive:https://drive.google.com/drive/folders/1pG3qfcOhxeGS7zaQngdTLXvjO8nxKUAL?usp=drive_link
