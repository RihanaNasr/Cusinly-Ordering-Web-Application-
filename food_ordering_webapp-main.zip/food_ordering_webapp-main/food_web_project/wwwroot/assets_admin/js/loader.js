$(window).on('load', function(event) {
    event.preventDefault();
    $('#eq-loader').hide();
});