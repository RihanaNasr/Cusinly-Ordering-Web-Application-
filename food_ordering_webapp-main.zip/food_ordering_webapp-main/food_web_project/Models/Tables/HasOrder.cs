﻿namespace food_web_project.Models.Tables
{
    public class HasOrder
    {
        public OrderItems OrderItemID { get; set; }
        public Order OrderID { get; set; }

    }
}
