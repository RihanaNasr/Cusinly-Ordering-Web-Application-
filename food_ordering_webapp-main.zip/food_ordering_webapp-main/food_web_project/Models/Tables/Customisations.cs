﻿namespace food_web_project.Models.Tables
{
    public class Customisations
    {
        public int CustomizationID { get; set; }
        public int Price { get; set; }
        public string Description { get; set; }
        public string Availability { get; set; }
    }
}
