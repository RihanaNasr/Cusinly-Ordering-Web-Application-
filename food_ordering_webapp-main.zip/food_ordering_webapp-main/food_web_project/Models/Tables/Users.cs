﻿
namespace food_web_project.Models.Tables
{
    public class Users
    {
        public int UserId { get; set; }
        public string Password { get; set; }
        public string Username { get; set; }
       
    }
}
