﻿namespace food_web_project.Models.Tables
{
    public class Review
    {
        public int ReviewID { get; set; }
        public int Rate { get; set; }
        public string Comment { get; set;}
        public string Date { get; set; }
    }
}
