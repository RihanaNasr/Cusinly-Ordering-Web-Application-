﻿using Microsoft.AspNetCore.Mvc;

namespace food_web_project.Models.Tables
{
    public class CustomerPayments
    {
        public Users CustomerId { get; set; }
        public Promotion CouponID { get; set; }

    }
}
