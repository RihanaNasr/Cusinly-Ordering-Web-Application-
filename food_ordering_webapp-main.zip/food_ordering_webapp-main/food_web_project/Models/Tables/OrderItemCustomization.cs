﻿namespace food_web_project.Models.Tables
{
    public class OrderItemCustomization
    {
        public OrderItems OrderItemID { get; set; }
        public Customisations CustomizationID { get; set; }
    }
}
