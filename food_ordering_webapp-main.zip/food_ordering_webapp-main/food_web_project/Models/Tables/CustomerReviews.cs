﻿namespace food_web_project.Models.Tables
{
    public class CustomerReviews
    {
        public Review ReviewID { get; set; }
        public Users CustomerId { get; set; }

    }
}
